//
//  TabBarController.swift
//  TripShoot
//
//  Created by Demon on 16/8/31.
//  Copyright © 2016年 冰心. All rights reserved.
//

import UIKit

class TabBarController: BaseTabBarController {

    
    override func viewDidLoad() {
        super.viewDidLoad()
        addChildViewControllers()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
       
    
    private func addChildViewControllers(){
        addChildViewController(HomeViewController(), title: "首页", imageName: "tabbar_home")
        addChildViewController(ShopViewController(), title: "商品", imageName: "tabbar_home")
        addChildViewController(HomeViewController(), title: "发现", imageName: "tabbar_home")
        addChildViewController(MyViewController(), title: "我", imageName: "tabbar_home")
        
    }
    
    private func addChildViewController(controller: UIViewController, title:String, imageName:String){
        
        controller.tabBarItem.image = UIImage(named: imageName)
        controller.tabBarItem.selectedImage = UIImage(named: imageName + "_selected")
        controller.tabBarItem.title = title
        
        let nav = NavigationController()
        nav.addChildViewController(controller)
        addChildViewController(nav)
    }

}
